﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ayudacard_api.Entities
{
    public class MstCivilStatus
    {
        public Int32 Id { get; set; }
        public String CivilStatus { get; set; }
    }
}