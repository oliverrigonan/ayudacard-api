﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ayudacard_api.Entities
{
    public class MstCitizenship
    {
        public Int32 Id { get; set; }
        public String Citizenship { get; set; }
    }
}