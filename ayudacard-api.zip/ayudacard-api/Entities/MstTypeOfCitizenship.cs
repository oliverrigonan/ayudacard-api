﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ayudacard_api.Entities
{
    public class MstTypeOfCitizenship
    {
        public Int32 Id { get; set; }
        public String TypeOfCitizenship { get; set; }
    }
}