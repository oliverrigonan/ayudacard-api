﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ayudacard_api
{
    public class app_configuration
    {
        public String PhotosBackUpStoragePath { get; set; }
    }
}